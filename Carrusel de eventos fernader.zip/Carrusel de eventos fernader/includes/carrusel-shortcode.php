<?php
/**
 * Shortcode para mostrar el carrusel de eventos
 */
add_shortcode('carrusel_eventos', 'ec_carrusel_eventos_shortcode');
function ec_carrusel_eventos_shortcode($atts) {
    // Atributos del shortcode
    $atts = shortcode_atts(array(
        'ubicacion'      => '',
        'posts_per_page' => 6,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'mostrar_todos'  => '',
        'button_text'    => 'RSVP',
        'link_type'      => 'custom',
        'link_attrs'     => '',
        'slides_desktop' => 3,
        'slides_tablet'  => 2,
        'slides_mobile'  => 1,
        'space_between'  => 24,
        'image_fit'      => 'cover',
    ), $atts, 'carrusel_eventos');
    
    // Argumentos de la consulta
    $args = array(
        'post_type' => 'eventos',
        'posts_per_page' => intval($atts['posts_per_page']),
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
    );
    
    // Filtrar por ubicación si se especifica
    if (!empty($atts['ubicacion'])) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'ubicacion_evento',
                'field' => 'slug',
                'terms' => $atts['ubicacion'],
            ),
        );
    }
    
    // Filtrar solo eventos futuros (incluyendo hoy) SI NO está activado "mostrar_todos"
    if ($atts['mostrar_todos'] !== 'yes') {
        $args['meta_query'] = array(
            array(
                'key' => '_evento_fecha',
                'value' => date('Y-m-d'), // Fecha de hoy
                'compare' => '>=',
                'type' => 'DATE'
            )
        );
        
        // Ordenar por fecha del evento si orderby es 'date'
        if ($atts['orderby'] === 'date') {
            $args['meta_key'] = '_evento_fecha';
            $args['orderby'] = 'meta_value';
            $args['order'] = 'ASC'; // Eventos más próximos primero
        }
    }
    
    // Ejecutar la consulta
    $eventos_query = new WP_Query($args);
    
    // Si no hay eventos, retornar vacío
    if (!$eventos_query->have_posts()) {
        return '<p>' . __('No se encontraron eventos.', 'eventos-carrusel') . '</p>';
    }
    
    // Iniciar el buffer de salida
    ob_start();
    // ID único para esta instancia del carrusel
    $instance_id = 'ec-carrusel-' . uniqid();
    ?>

    <div class="ec-carrusel-wrapper" id="wrapper-<?php echo esc_attr($instance_id); ?>">
        <!-- Custom Nav (moved outside container so overflow:hidden doesn't clip) -->
        <div class="ec-nav-buttons">
            <div class="ec-nav-btn" id="<?php echo esc_attr($instance_id); ?>-prev">&lt;</div>
            <div class="ec-nav-btn" id="<?php echo esc_attr($instance_id); ?>-next">&gt;</div>
        </div>

        <div id="<?php echo esc_attr($instance_id); ?>"
             class="ec-carrusel-container swiper"
             data-slides-desktop="<?php echo intval($atts['slides_desktop']); ?>"
             data-slides-tablet="<?php echo intval($atts['slides_tablet']); ?>"
             data-slides-mobile="<?php echo intval($atts['slides_mobile']); ?>"
             data-space-between="<?php echo intval($atts['space_between']); ?>">

            <!-- Scroll Container -->
            <div class="ec-scroll-container swiper-wrapper">

                <?php while ($eventos_query->have_posts()) : $eventos_query->the_post(); ?>

                    <div class="ec-card swiper-slide">

                        <!-- Background Image -->
                        <?php if (has_post_thumbnail()) : ?>
                            <?php
                            $fit = esc_attr($atts['image_fit']);
                            $img_url = get_the_post_thumbnail_url(get_the_ID(), 'large');
                            $alt_text = get_the_title();
                            ?>
                            <img
                                src="<?php echo esc_url($img_url); ?>"
                                alt="<?php echo esc_attr($alt_text); ?>"
                                class="ec-bg-image"
                                style="object-fit: <?php echo $fit; ?>;"
                            />
                        <?php else : ?>
                            <img src="<?php echo esc_url(EC_PLUGIN_URL); ?>assets/images/placeholder.jpg" alt="<?php the_title_attribute(); ?>" class="ec-bg-image" style="object-fit: <?php echo esc_attr($atts['image_fit']); ?>;" />
                        <?php endif; ?>

                        <!-- Overlay -->
                        <div class="ec-overlay"></div>

                        <!-- Content -->
                        <div class="ec-content">
                            <div class="ec-content-inner">
                                <!-- Location -->
                            <?php
                            $ubicaciones = get_the_terms(get_the_ID(), 'ubicacion_evento');
                            if ($ubicaciones && !is_wp_error($ubicaciones)) :
                                $ubicacion_name = $ubicaciones[0]->name;
                            ?>
                                <div class="ec-location">
                                    <svg class="ec-pin" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                                    </svg>
                                    <span class="ec-location-text"><?php echo esc_html(strtoupper($ubicacion_name)); ?></span>
                                </div>
                            <?php endif; ?>
                            
                            <!-- Title -->
                            <h3 class="ec-title"><?php echo esc_html(strtoupper(get_the_title())); ?></h3>
                        </div>

                        <!-- RSVP Button -->
                        <div class="ec-rsvp-container">
                            <?php
                            $mostrar_boton = get_post_meta(get_the_ID(), '_evento_mostrar_boton', true);
                            if ($mostrar_boton === 'yes') {
                                $link_attributes = '';
                                if ($atts['link_type'] === 'permalink') {
                                    $link_attributes = 'href="' . esc_url(get_permalink()) . '"';
                                } else {
                                    if (!empty($atts['link_attrs'])) {
                                        $link_attributes = base64_decode($atts['link_attrs']);
                                    } else {
                                        $link_attributes = 'href="#"';
                                    }
                                }
                            ?>
                            <a class="ec-rsvp-btn" <?php echo $link_attributes; ?>>
                                <?php echo esc_html($atts['button_text']); ?>
                            </a>
                            <?php } ?>
                        </div>
                        </div>

                        <?php
                        $popup_content = apply_filters('the_content', get_the_content());
                        $popup_content = wp_kses_post($popup_content);
                        if (!empty(trim(strip_tags($popup_content)))) :
                        ?>
                        <div class="ec-popup-data" aria-hidden="true" style="display:none;">
                            <?php echo $popup_content; ?>
                        </div>
                        <?php endif; ?>

                    </div>

                <?php endwhile; ?>

            </div> <!-- .ec-scroll-container -->
            
        </div> <!-- .ec-carrusel-container -->
    </div> <!-- .ec-carrusel-wrapper -->
    
    <?php
    wp_reset_postdata();
    
    return ob_get_clean();
}
