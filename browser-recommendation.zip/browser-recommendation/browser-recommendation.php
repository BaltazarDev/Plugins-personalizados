<?php
/**
 * Plugin Name: Browser Recommendation Banner
 * Plugin URI:  https://example.com
 * Description: Muestra un banner personalizable recomendando Chrome o Edge a usuarios de Safari y Firefox.
 * Version:     1.0.0
 * Author:      Tu Nombre
 * License:     GPL2
 * Text Domain: browser-rec
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ──────────────────────────────────────────────
// 1. DEFAULTS
// ──────────────────────────────────────────────
function brec_defaults() {
    return [
        'enabled'          => 1,
        'title'            => '¡Mejora tu experiencia!',
        'message'          => 'Parece que estás usando un navegador que puede no ofrecer la mejor experiencia en este sitio. Te recomendamos usar <strong>Google Chrome</strong> o <strong>Microsoft Edge</strong> para disfrutar de todas las funcionalidades.',
        'btn_chrome_text'  => '⬇ Descargar Chrome',
        'btn_chrome_url'   => 'https://www.google.com/chrome/',
        'btn_edge_text'    => '⬇ Descargar Edge',
        'btn_edge_url'     => 'https://www.microsoft.com/edge',
        'btn_dismiss_text' => 'Continuar de todos modos',
        'position'         => 'top',          // top | bottom | modal
        'detect_safari'    => 1,
        'detect_firefox'   => 1,
        // Colors
        'bg_color'         => '#0f172a',
        'text_color'       => '#e2e8f0',
        'title_color'      => '#f8fafc',
        'accent_color'     => '#6366f1',
        'btn_primary_bg'   => '#6366f1',
        'btn_primary_text' => '#ffffff',
        'btn_secondary_bg' => '#1e293b',
        'btn_secondary_text'=> '#94a3b8',
        'overlay_color'    => 'rgba(0,0,0,0.7)',
        // Typography
        'font_family'      => 'inherit',
        'title_size'       => '22',
        'message_size'     => '15',
        'btn_size'         => '14',
        // Spacing / misc
        'border_radius'    => '12',
        'show_icon'        => 1,
        'animation'        => 'slide',        // slide | fade | none
        'cookie_days'      => '7',
    ];
}

// ──────────────────────────────────────────────
// 2. SETTINGS PAGE
// ──────────────────────────────────────────────
add_action( 'admin_menu', function () {
    add_options_page(
        'Browser Recommendation',
        'Browser Recommendation',
        'manage_options',
        'browser-rec',
        'brec_settings_page'
    );
} );

add_action( 'admin_init', function () {
    register_setting( 'brec_group', 'brec_options', [ 'sanitize_callback' => 'brec_sanitize' ] );
} );

function brec_sanitize( $input ) {
    $defaults = brec_defaults();
    $clean    = [];
    foreach ( $defaults as $key => $default ) {
        if ( in_array( $key, [ 'enabled', 'detect_safari', 'detect_firefox', 'show_icon' ] ) ) {
            $clean[ $key ] = isset( $input[ $key ] ) ? 1 : 0;
        } elseif ( in_array( $key, [ 'bg_color','text_color','title_color','accent_color','btn_primary_bg','btn_primary_text','btn_secondary_bg','btn_secondary_text' ] ) ) {
            $clean[ $key ] = sanitize_hex_color( $input[ $key ] ?? $default ) ?: $default;
        } else {
            $clean[ $key ] = sanitize_text_field( $input[ $key ] ?? $default );
        }
    }
    // allow HTML in message
    if ( isset( $input['message'] ) ) {
        $clean['message'] = wp_kses( $input['message'], [ 'strong'=>[], 'em'=>[], 'a'=>['href'=>[],'target'=>[]] ] );
    }
    return $clean;
}

function brec_opt( $key = null ) {
    $opts = wp_parse_args( get_option( 'brec_options', [] ), brec_defaults() );
    return $key ? ( $opts[ $key ] ?? null ) : $opts;
}

function brec_settings_page() {
    $o = brec_opt();
    ?>
    <div class="wrap" id="brec-admin">
    <h1 style="display:flex;align-items:center;gap:10px;">
        <span style="font-size:28px;">🌐</span> Browser Recommendation Banner
    </h1>
    <p style="color:#666;">Muestra un aviso personalizado a usuarios de Safari y Firefox sugiriendo Chrome o Edge.</p>

    <form method="post" action="options.php">
        <?php settings_fields( 'brec_group' ); ?>

        <div class="brec-tabs">
            <button type="button" class="brec-tab active" data-tab="general">⚙️ General</button>
            <button type="button" class="brec-tab" data-tab="content">✏️ Contenido</button>
            <button type="button" class="brec-tab" data-tab="design">🎨 Diseño</button>
            <button type="button" class="brec-tab" data-tab="preview">👁 Vista previa</button>
        </div>

        <!-- GENERAL -->
        <div class="brec-panel active" id="tab-general">
            <table class="form-table">
                <tr>
                    <th>Activar banner</th>
                    <td><label><input type="checkbox" name="brec_options[enabled]" value="1" <?php checked($o['enabled'],1); ?>> Mostrar el banner</label></td>
                </tr>
                <tr>
                    <th>Detectar Safari</th>
                    <td><label><input type="checkbox" name="brec_options[detect_safari]" value="1" <?php checked($o['detect_safari'],1); ?>> Mostrar aviso a usuarios de Safari</label></td>
                </tr>
                <tr>
                    <th>Detectar Firefox</th>
                    <td><label><input type="checkbox" name="brec_options[detect_firefox]" value="1" <?php checked($o['detect_firefox'],1); ?>> Mostrar aviso a usuarios de Firefox</label></td>
                </tr>
                <tr>
                    <th>Posición</th>
                    <td>
                        <select name="brec_options[position]">
                            <option value="top"    <?php selected($o['position'],'top'); ?>>Barra superior</option>
                            <option value="bottom" <?php selected($o['position'],'bottom'); ?>>Barra inferior</option>
                            <option value="modal"  <?php selected($o['position'],'modal'); ?>>Modal centrado</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Animación</th>
                    <td>
                        <select name="brec_options[animation]">
                            <option value="slide" <?php selected($o['animation'],'slide'); ?>>Deslizar</option>
                            <option value="fade"  <?php selected($o['animation'],'fade'); ?>>Desvanecer</option>
                            <option value="none"  <?php selected($o['animation'],'none'); ?>>Sin animación</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Días antes de volver a mostrar</th>
                    <td><input type="number" name="brec_options[cookie_days]" value="<?php echo esc_attr($o['cookie_days']); ?>" min="0" max="365" style="width:80px;"> días <span class="description">(0 = mostrar siempre)</span></td>
                </tr>
                <tr>
                    <th>Mostrar icono del navegador</th>
                    <td><label><input type="checkbox" name="brec_options[show_icon]" value="1" <?php checked($o['show_icon'],1); ?>> Mostrar icono</label></td>
                </tr>
            </table>
        </div>

        <!-- CONTENT -->
        <div class="brec-panel" id="tab-content">
            <table class="form-table">
                <tr>
                    <th>Título</th>
                    <td><input type="text" name="brec_options[title]" value="<?php echo esc_attr($o['title']); ?>" class="large-text"></td>
                </tr>
                <tr>
                    <th>Mensaje</th>
                    <td>
                        <textarea name="brec_options[message]" rows="4" class="large-text"><?php echo esc_textarea($o['message']); ?></textarea>
                        <p class="description">Puedes usar &lt;strong&gt;, &lt;em&gt; y &lt;a href=""&gt;</p>
                    </td>
                </tr>
                <tr><th colspan="2"><h3 style="margin:0">Botón Chrome</h3></th></tr>
                <tr>
                    <th>Texto botón Chrome</th>
                    <td><input type="text" name="brec_options[btn_chrome_text]" value="<?php echo esc_attr($o['btn_chrome_text']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>URL Chrome</th>
                    <td><input type="url" name="brec_options[btn_chrome_url]" value="<?php echo esc_attr($o['btn_chrome_url']); ?>" class="large-text"></td>
                </tr>
                <tr><th colspan="2"><h3 style="margin:0">Botón Edge</h3></th></tr>
                <tr>
                    <th>Texto botón Edge</th>
                    <td><input type="text" name="brec_options[btn_edge_text]" value="<?php echo esc_attr($o['btn_edge_text']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>URL Edge</th>
                    <td><input type="url" name="brec_options[btn_edge_url]" value="<?php echo esc_attr($o['btn_edge_url']); ?>" class="large-text"></td>
                </tr>
                <tr>
                    <th>Texto "Cerrar"</th>
                    <td><input type="text" name="brec_options[btn_dismiss_text]" value="<?php echo esc_attr($o['btn_dismiss_text']); ?>" class="regular-text"></td>
                </tr>
            </table>
        </div>

        <!-- DESIGN -->
        <div class="brec-panel" id="tab-design">
            <table class="form-table">
                <tr><th colspan="2"><h3 style="margin:0">Colores</h3></th></tr>
                <tr>
                    <th>Fondo del banner</th>
                    <td><input type="color" name="brec_options[bg_color]" value="<?php echo esc_attr($o['bg_color']); ?>"> <code><?php echo esc_html($o['bg_color']); ?></code></td>
                </tr>
                <tr>
                    <th>Color del texto</th>
                    <td><input type="color" name="brec_options[text_color]" value="<?php echo esc_attr($o['text_color']); ?>"></td>
                </tr>
                <tr>
                    <th>Color del título</th>
                    <td><input type="color" name="brec_options[title_color]" value="<?php echo esc_attr($o['title_color']); ?>"></td>
                </tr>
                <tr>
                    <th>Color de acento (bordes, iconos)</th>
                    <td><input type="color" name="brec_options[accent_color]" value="<?php echo esc_attr($o['accent_color']); ?>"></td>
                </tr>
                <tr>
                    <th>Botones primarios — fondo</th>
                    <td><input type="color" name="brec_options[btn_primary_bg]" value="<?php echo esc_attr($o['btn_primary_bg']); ?>"></td>
                </tr>
                <tr>
                    <th>Botones primarios — texto</th>
                    <td><input type="color" name="brec_options[btn_primary_text]" value="<?php echo esc_attr($o['btn_primary_text']); ?>"></td>
                </tr>
                <tr>
                    <th>Botón "Continuar" — fondo</th>
                    <td><input type="color" name="brec_options[btn_secondary_bg]" value="<?php echo esc_attr($o['btn_secondary_bg']); ?>"></td>
                </tr>
                <tr>
                    <th>Botón "Continuar" — texto</th>
                    <td><input type="color" name="brec_options[btn_secondary_text]" value="<?php echo esc_attr($o['btn_secondary_text']); ?>"></td>
                </tr>
                <tr>
                    <th>Overlay (solo modal)</th>
                    <td><input type="text" name="brec_options[overlay_color]" value="<?php echo esc_attr($o['overlay_color']); ?>" class="regular-text" placeholder="rgba(0,0,0,0.7)"></td>
                </tr>

                <tr><th colspan="2"><h3 style="margin:0">Tipografía</h3></th></tr>
                <tr>
                    <th>Familia de fuente</th>
                    <td>
                        <select name="brec_options[font_family]">
                            <option value="inherit"            <?php selected($o['font_family'],'inherit'); ?>>Heredar del tema</option>
                            <option value="'Segoe UI',sans-serif" <?php selected($o['font_family'],"'Segoe UI',sans-serif"); ?>>Segoe UI</option>
                            <option value="Georgia,serif"      <?php selected($o['font_family'],'Georgia,serif'); ?>>Georgia</option>
                            <option value="'Courier New',monospace" <?php selected($o['font_family'],"'Courier New',monospace"); ?>>Courier New</option>
                            <option value="'Trebuchet MS',sans-serif" <?php selected($o['font_family'],"'Trebuchet MS',sans-serif"); ?>>Trebuchet MS</option>
                        </select>
                        <span class="description"> o escribe una fuente de Google Fonts ya cargada en tu tema.</span>
                    </td>
                </tr>
                <tr>
                    <th>Tamaño del título (px)</th>
                    <td><input type="number" name="brec_options[title_size]" value="<?php echo esc_attr($o['title_size']); ?>" min="12" max="60" style="width:80px;"></td>
                </tr>
                <tr>
                    <th>Tamaño del mensaje (px)</th>
                    <td><input type="number" name="brec_options[message_size]" value="<?php echo esc_attr($o['message_size']); ?>" min="10" max="40" style="width:80px;"></td>
                </tr>
                <tr>
                    <th>Tamaño de botones (px)</th>
                    <td><input type="number" name="brec_options[btn_size]" value="<?php echo esc_attr($o['btn_size']); ?>" min="10" max="30" style="width:80px;"></td>
                </tr>
                <tr>
                    <th>Border radius (px)</th>
                    <td><input type="number" name="brec_options[border_radius]" value="<?php echo esc_attr($o['border_radius']); ?>" min="0" max="40" style="width:80px;"></td>
                </tr>
            </table>
        </div>

        <!-- PREVIEW -->
        <div class="brec-panel" id="tab-preview">
            <p style="color:#888;">Guarda los cambios y luego visita el sitio con Safari o Firefox (o usa las DevTools de Chrome para cambiar el User Agent) para ver el banner en acción.</p>
            <div id="brec-live-preview" style="margin-top:20px;border:2px dashed #ddd;border-radius:8px;padding:20px;background:#f9f9f9;">
                <p style="color:#888;text-align:center;">Vista previa estática basada en los valores guardados</p>
                <?php brec_render_preview( $o ); ?>
            </div>
        </div>

        <?php submit_button( 'Guardar cambios' ); ?>
    </form>
    </div>

    <style>
    #brec-admin { max-width: 900px; }
    .brec-tabs { display:flex; gap:4px; margin-bottom:0; border-bottom:2px solid #ddd; padding-bottom:0; }
    .brec-tab { background:none; border:none; padding:10px 18px; cursor:pointer; font-size:14px; color:#555; border-radius:6px 6px 0 0; border:1px solid transparent; margin-bottom:-2px; }
    .brec-tab.active { background:#fff; border-color:#ddd #ddd #fff; color:#2271b1; font-weight:600; }
    .brec-panel { display:none; background:#fff; border:1px solid #ddd; border-top:none; padding:20px; border-radius:0 6px 6px 6px; }
    .brec-panel.active { display:block; }
    </style>
    <script>
    document.querySelectorAll('.brec-tab').forEach(function(btn){
        btn.addEventListener('click', function(){
            document.querySelectorAll('.brec-tab').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.brec-panel').forEach(p => p.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
        });
    });
    </script>
    <?php
}

function brec_render_preview( $o ) {
    $position = $o['position'];
    $is_modal = $position === 'modal';
    $style = "
        background:{$o['bg_color']};
        color:{$o['text_color']};
        font-family:{$o['font_family']};
        border-radius:{$o['border_radius']}px;
        padding:24px 28px;
        " . ($is_modal ? "max-width:480px;margin:0 auto;" : "width:100%;box-sizing:border-box;") . "
    ";
    echo "<div style='{$style}'>";
    if ( $o['show_icon'] ) {
        echo "<div style='font-size:36px;margin-bottom:12px;'>🌐</div>";
    }
    echo "<div style='font-size:{$o['title_size']}px;font-weight:700;color:{$o['title_color']};margin-bottom:10px;'>" . esc_html($o['title']) . "</div>";
    echo "<div style='font-size:{$o['message_size']}px;line-height:1.6;margin-bottom:20px;'>" . wp_kses_post($o['message']) . "</div>";
    $btn_r = min( (int)$o['border_radius'], 8 );
    echo "<div style='display:flex;flex-wrap:wrap;gap:10px;align-items:center;'>";
    echo "<a href='#' style='background:{$o['btn_primary_bg']};color:{$o['btn_primary_text']};font-size:{$o['btn_size']}px;padding:10px 20px;border-radius:{$btn_r}px;text-decoration:none;font-weight:600;'>" . esc_html($o['btn_chrome_text']) . "</a>";
    echo "<a href='#' style='background:{$o['btn_primary_bg']};color:{$o['btn_primary_text']};font-size:{$o['btn_size']}px;padding:10px 20px;border-radius:{$btn_r}px;text-decoration:none;font-weight:600;'>" . esc_html($o['btn_edge_text']) . "</a>";
    echo "<a href='#' style='background:{$o['btn_secondary_bg']};color:{$o['btn_secondary_text']};font-size:{$o['btn_size']}px;padding:8px 16px;border-radius:{$btn_r}px;text-decoration:none;'>" . esc_html($o['btn_dismiss_text']) . "</a>";
    echo "</div>";
    echo "</div>";
}

// ──────────────────────────────────────────────
// 3. FRONTEND OUTPUT
// ──────────────────────────────────────────────
add_action( 'wp_footer', 'brec_frontend_output' );
function brec_frontend_output() {
    $o = brec_opt();
    if ( ! $o['enabled'] ) return;

    $detect_safari  = $o['detect_safari']  ? 'true' : 'false';
    $detect_firefox = $o['detect_firefox'] ? 'true' : 'false';
    $position       = esc_js( $o['position'] );
    $animation      = esc_js( $o['animation'] );
    $cookie_days    = intval( $o['cookie_days'] );
    $show_icon      = $o['show_icon'] ? 'true' : 'false';

    $title       = esc_js( $o['title'] );
    $message     = addslashes( $o['message'] );
    $btn_chrome  = esc_js( $o['btn_chrome_text'] );
    $chrome_url  = esc_url( $o['btn_chrome_url'] );
    $btn_edge    = esc_js( $o['btn_edge_text'] );
    $edge_url    = esc_url( $o['btn_edge_url'] );
    $btn_dismiss = esc_js( $o['btn_dismiss_text'] );

    $css_vars = "
        --brec-bg:       {$o['bg_color']};
        --brec-text:     {$o['text_color']};
        --brec-title:    {$o['title_color']};
        --brec-accent:   {$o['accent_color']};
        --brec-btn-pbg:  {$o['btn_primary_bg']};
        --brec-btn-ptx:  {$o['btn_primary_text']};
        --brec-btn-sbg:  {$o['btn_secondary_bg']};
        --brec-btn-stx:  {$o['btn_secondary_text']};
        --brec-overlay:  {$o['overlay_color']};
        --brec-font:     {$o['font_family']};
        --brec-title-sz: {$o['title_size']}px;
        --brec-msg-sz:   {$o['message_size']}px;
        --brec-btn-sz:   {$o['btn_size']}px;
        --brec-radius:   {$o['border_radius']}px;
    ";

    ?>
<style id="brec-css">
:root { <?php echo $css_vars; ?> }

#brec-wrap {
    font-family: var(--brec-font);
    box-sizing: border-box;
    z-index: 999999;
}

/* ── BAR (top / bottom) ── */
#brec-wrap.brec-bar {
    position: fixed;
    left: 0; right: 0;
    background: var(--brec-bg);
    color: var(--brec-text);
    padding: 14px 20px;
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
    box-shadow: 0 4px 24px rgba(0,0,0,.35);
}
#brec-wrap.brec-bar.brec-top    { top: 0; border-bottom: 2px solid var(--brec-accent); }
#brec-wrap.brec-bar.brec-bottom { bottom: 0; border-top: 2px solid var(--brec-accent); }

/* ── MODAL ── */
#brec-overlay {
    position: fixed; inset: 0;
    background: var(--brec-overlay);
    z-index: 999998;
    display: flex; align-items: center; justify-content: center;
    padding: 16px;
}
#brec-wrap.brec-modal {
    position: relative;
    background: var(--brec-bg);
    color: var(--brec-text);
    border-radius: var(--brec-radius);
    padding: 36px 32px;
    max-width: 500px; width: 100%;
    box-shadow: 0 24px 64px rgba(0,0,0,.5);
    border: 1px solid var(--brec-accent);
}

/* ── ICON ── */
.brec-icon { font-size: 40px; margin-bottom: 14px; display: block; }

/* ── TITLE ── */
.brec-title {
    font-size: var(--brec-title-sz);
    font-weight: 700;
    color: var(--brec-title);
    margin: 0 0 10px;
    line-height: 1.3;
}

/* ── MESSAGE ── */
.brec-msg {
    font-size: var(--brec-msg-sz);
    line-height: 1.65;
    margin: 0 0 20px;
    flex: 1 1 300px;
}
.brec-msg strong { color: var(--brec-title); }

/* ── BUTTONS ── */
.brec-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    align-items: center;
}
.brec-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: var(--brec-btn-sz);
    font-weight: 600;
    padding: 10px 20px;
    border-radius: calc(var(--brec-radius) * .6);
    text-decoration: none;
    cursor: pointer;
    border: none;
    transition: filter .2s, transform .15s;
    white-space: nowrap;
}
.brec-btn:hover { filter: brightness(1.12); transform: translateY(-1px); }
.brec-btn-primary  { background: var(--brec-btn-pbg); color: var(--brec-btn-ptx); }
.brec-btn-dismiss  { background: var(--brec-btn-sbg); color: var(--brec-btn-stx); font-weight: 400; }

/* ── CLOSE X ── */
.brec-close {
    position: absolute; top: 14px; right: 16px;
    background: none; border: none;
    color: var(--brec-text);
    font-size: 22px; cursor: pointer;
    opacity: .6; transition: opacity .2s;
    line-height: 1;
}
.brec-close:hover { opacity: 1; }

/* ── ANIMATIONS ── */
@keyframes brec-slide-down   { from{transform:translateY(-100%);opacity:0} to{transform:translateY(0);opacity:1} }
@keyframes brec-slide-up     { from{transform:translateY(100%);opacity:0}  to{transform:translateY(0);opacity:1} }
@keyframes brec-fade-in      { from{opacity:0} to{opacity:1} }
@keyframes brec-modal-in     { from{transform:scale(.92) translateY(20px);opacity:0} to{transform:scale(1) translateY(0);opacity:1} }

.brec-anim-slide.brec-top    { animation: brec-slide-down .4s cubic-bezier(.22,1,.36,1) forwards; }
.brec-anim-slide.brec-bottom { animation: brec-slide-up   .4s cubic-bezier(.22,1,.36,1) forwards; }
.brec-anim-slide.brec-modal  { animation: brec-modal-in   .35s cubic-bezier(.22,1,.36,1) forwards; }
.brec-anim-fade              { animation: brec-fade-in .5s ease forwards; }

/* ── RESPONSIVE ── */
@media (max-width: 600px) {
    #brec-wrap.brec-bar { flex-direction: column; align-items: flex-start; padding: 16px; }
    .brec-actions       { width: 100%; }
    .brec-btn           { flex: 1 1 auto; justify-content: center; }
    .brec-title         { font-size: calc(var(--brec-title-sz) * .85); }
    .brec-msg           { font-size: calc(var(--brec-msg-sz) * .95); }
    #brec-wrap.brec-modal { padding: 28px 20px; }
}
</style>

<script id="brec-js">
(function(){
    var COOKIE_KEY  = 'brec_dismissed';
    var DETECT_S    = <?php echo $detect_safari; ?>;
    var DETECT_F    = <?php echo $detect_firefox; ?>;
    var POSITION    = '<?php echo $position; ?>';
    var ANIMATION   = '<?php echo $animation; ?>';
    var COOKIE_DAYS = <?php echo $cookie_days; ?>;
    var SHOW_ICON   = <?php echo $show_icon; ?>;

    function isSafari() {
        var ua = navigator.userAgent;
        return /Safari/.test(ua) && !/Chrome|CriOS|FxiOS/.test(ua);
    }
    function isFirefox() {
        return /Firefox|FxiOS/.test(navigator.userAgent);
    }
    function getCookie(name) {
        var v = document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)');
        return v ? v.pop() : null;
    }
    function setCookie(name, days) {
        var d = new Date();
        d.setTime(d.getTime() + days * 864e5);
        document.cookie = name + '=1;expires=' + d.toUTCString() + ';path=/';
    }
    function dismiss() {
        if (COOKIE_DAYS > 0) setCookie(COOKIE_KEY, COOKIE_DAYS);
        var overlay = document.getElementById('brec-overlay');
        var wrap    = document.getElementById('brec-wrap');
        if (overlay) overlay.remove();
        if (wrap)    wrap.remove();
    }

    // Check if should show
    var shouldShow = (DETECT_S && isSafari()) || (DETECT_F && isFirefox());
    if (!shouldShow) return;
    if (COOKIE_DAYS > 0 && getCookie(COOKIE_KEY)) return;

    var isModal = POSITION === 'modal';

    // Build HTML
    var icon    = SHOW_ICON ? '<span class="brec-icon">🌐</span>' : '';
    var closeX  = '<button class="brec-close" aria-label="Cerrar">&times;</button>';
    var animCls = ANIMATION === 'none' ? '' : (' brec-anim-' + ANIMATION);

    var inner = icon +
        closeX +
        '<div class="brec-title"><?php echo $title; ?></div>' +
        '<div class="brec-msg"><?php echo $message; ?></div>' +
        '<div class="brec-actions">' +
            '<a href="<?php echo $chrome_url; ?>" target="_blank" rel="noopener" class="brec-btn brec-btn-primary">📥 <?php echo $btn_chrome; ?></a>' +
            '<a href="<?php echo $edge_url; ?>" target="_blank" rel="noopener" class="brec-btn brec-btn-primary">📥 <?php echo $btn_edge; ?></a>' +
            '<button class="brec-btn brec-btn-dismiss"><?php echo $btn_dismiss; ?></button>' +
        '</div>';

    var wrap = document.createElement('div');
    wrap.id  = 'brec-wrap';

    if (isModal) {
        wrap.className = 'brec-modal brec-' + POSITION + animCls;
        wrap.innerHTML = inner;

        var overlay = document.createElement('div');
        overlay.id  = 'brec-overlay';
        overlay.appendChild(wrap);
        document.body.appendChild(overlay);

        overlay.addEventListener('click', function(e){ if(e.target===overlay) dismiss(); });
    } else {
        wrap.className = 'brec-bar brec-' + POSITION + animCls;
        wrap.innerHTML = inner;
        document.body.appendChild(wrap);

        // Push body content down for top bar
        if (POSITION === 'top') {
            var adj = function(){
                document.body.style.paddingTop = (wrap.offsetHeight + 'px');
            };
            adj();
            window.addEventListener('resize', adj);
        }
        if (POSITION === 'bottom') {
            var adjB = function(){
                document.body.style.paddingBottom = (wrap.offsetHeight + 'px');
            };
            adjB();
            window.addEventListener('resize', adjB);
        }
    }

    // Dismiss handlers
    document.querySelectorAll('.brec-close, .brec-btn-dismiss').forEach(function(el){
        el.addEventListener('click', function(e){ e.preventDefault(); dismiss(); });
    });
})();
</script>
    <?php
}
