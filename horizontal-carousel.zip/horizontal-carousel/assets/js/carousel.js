/**
 * Horizontal Carousel - JavaScript
 * Fixes scroll positioning for embedded contexts (WordPress/Elementor)
 */

(function ($) {
    'use strict';

    /**
     * Initialize carousel when DOM is ready
     */
    $(document).ready(function () {
        initializeCarousels();
    });

    /**
     * Initialize all carousels on the page
     */
    function initializeCarousels() {
        $('.horizontal-carousel-section').each(function () {
            const carouselSection = $(this);
            const carouselId = carouselSection.attr('id');

            if (!carouselId) return;

            // Initialize this carousel instance
            new HorizontalCarousel(carouselSection, carouselId);
        });
    }

    /**
     * Horizontal Carousel Class
     */
    class HorizontalCarousel {
        constructor(section, carouselId) {
            this.section = section[0];
            this.carouselId = carouselId;
            this.track = this.section.querySelector('.horizontal-track[data-carousel="' + carouselId + '"]');
            this.prevBtn = document.querySelector('.horizontal-prev-btn[data-carousel="' + carouselId + '"]');
            this.nextBtn = document.querySelector('.horizontal-next-btn[data-carousel="' + carouselId + '"]');

            if (!this.track) return;

            this.isScrolling = false;
            this.rafId = null;

            this.init();
        }

        init() {
            // Bind scroll handler
            this.handleScroll = this.handleScroll.bind(this);

            // Use scroll event with requestAnimationFrame for smooth performance
            $(window).on('scroll', () => {
                if (!this.isScrolling) {
                    this.isScrolling = true;
                    this.rafId = requestAnimationFrame(this.handleScroll);
                }
            });

            // Handle resize
            $(window).on('resize', () => {
                this.handleScroll();
            });

            // Button navigation
            if (this.prevBtn) {
                $(this.prevBtn).on('click', () => this.scrollPrev());
            }

            if (this.nextBtn) {
                $(this.nextBtn).on('click', () => this.scrollNext());
            }

            // Initial calculation
            this.handleScroll();
        }

        /**
         * CRITICAL FIX: Handle scroll with proper calculation for embedded contexts
         * This fixes the issue where slides 4-5 appear first instead of slide 1
         */
        handleScroll() {
            this.isScrolling = false;

            // Get section position relative to viewport
            const rect = this.section.getBoundingClientRect();
            const sectionHeight = this.section.offsetHeight;
            const viewportHeight = window.innerHeight;

            // Calculate when section enters and exits viewport
            const sectionTop = rect.top;
            const sectionBottom = rect.bottom;

            // Calculate scroll progress through the section
            // FIXED: Use viewport-relative calculations instead of offsetTop
            const scrollStart = -sectionTop; // How far section has scrolled into view from top
            const scrollEnd = sectionHeight - viewportHeight; // Total scrollable distance

            // Only animate when section is in viewport
            if (sectionBottom > 0 && sectionTop < viewportHeight) {
                // Calculate progress (0 to 1)
                let progress = scrollStart / scrollEnd;

                // Clamp progress between 0 and 1
                progress = Math.max(0, Math.min(1, progress));

                // Calculate horizontal translation
                const trackWidth = this.track.scrollWidth;
                const maxTranslate = trackWidth - window.innerWidth;
                const translateX = progress * maxTranslate;

                // Apply transform
                this.track.style.transform = `translateX(-${translateX}px)`;
            } else if (sectionTop >= viewportHeight) {
                // Section is below viewport - reset to start
                this.track.style.transform = 'translateX(0px)';
            } else if (sectionBottom <= 0) {
                // Section is above viewport - set to end
                const trackWidth = this.track.scrollWidth;
                const maxTranslate = trackWidth - window.innerWidth;
                this.track.style.transform = `translateX(-${maxTranslate}px)`;
            }
        }

        /**
         * Scroll to previous slide
         */
        scrollPrev() {
            const currentScroll = window.pageYOffset;
            const scrollAmount = window.innerHeight * 0.8; // Scroll by 80vh

            $('html, body').animate({
                scrollTop: currentScroll - scrollAmount
            }, 600, 'swing');
        }

        /**
         * Scroll to next slide
         */
        scrollNext() {
            const currentScroll = window.pageYOffset;
            const scrollAmount = window.innerHeight * 0.8; // Scroll by 80vh

            $('html, body').animate({
                scrollTop: currentScroll + scrollAmount
            }, 600, 'swing');
        }

        /**
         * Destroy carousel (cleanup)
         */
        destroy() {
            $(window).off('scroll', this.handleScroll);
            $(window).off('resize', this.handleScroll);

            if (this.prevBtn) {
                $(this.prevBtn).off('click');
            }

            if (this.nextBtn) {
                $(this.nextBtn).off('click');
            }

            if (this.rafId) {
                cancelAnimationFrame(this.rafId);
            }
        }
    }

    // Make it available globally if needed
    window.HorizontalCarousel = HorizontalCarousel;

    /**
     * Reinitialize on Elementor preview
     */
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/horizontal-carousel.default', function ($scope) {
            initializeCarousels();
        });
    });

})(jQuery);
