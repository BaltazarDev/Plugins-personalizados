<?php
/**
 * Plugin Name: Horizontal Carousel
 * Plugin URI: https://tu-sitio.com
 * Description: Carrusel horizontal con scroll para Elementor con selección de categoría
 * Version: 1.0.0
 * Author: Tu Nombre
 * Author URI: https://tu-sitio.com
 * Text Domain: horizontal-carousel
 * Domain Path: /languages
 * Elementor tested up to: 3.20.0
 * Elementor Pro tested up to: 3.20.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Main Horizontal Carousel Class
 */
final class Horizontal_Carousel {

    /**
     * Plugin Version
     */
    const VERSION = '1.0.0';

    /**
     * Minimum Elementor Version
     */
    const MINIMUM_ELEMENTOR_VERSION = '3.0.0';

    /**
     * Minimum PHP Version
     */
    const MINIMUM_PHP_VERSION = '7.4';

    /**
     * Instance
     */
    private static $_instance = null;

    /**
     * Instance
     */
    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * Constructor
     */
    public function __construct() {
        add_action('plugins_loaded', [$this, 'on_plugins_loaded']);
    }

    /**
     * Load Localization files
     */
    public function i18n() {
        load_plugin_textdomain('horizontal-carousel');
    }

    /**
     * On Plugins Loaded
     */
    public function on_plugins_loaded() {
        // Check if Elementor installed and activated
        if (!did_action('elementor/loaded')) {
            add_action('admin_notices', [$this, 'admin_notice_missing_main_plugin']);
            return;
        }

        // Check for required Elementor version
        if (!version_compare(ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=')) {
            add_action('admin_notices', [$this, 'admin_notice_minimum_elementor_version']);
            return;
        }

        // Check for required PHP version
        if (version_compare(PHP_VERSION, self::MINIMUM_PHP_VERSION, '<')) {
            add_action('admin_notices', [$this, 'admin_notice_minimum_php_version']);
            return;
        }

        // Add Plugin actions
        add_action('elementor/widgets/register', [$this, 'register_widgets']);
        add_action('elementor/frontend/after_enqueue_styles', [$this, 'enqueue_styles']);
        add_action('elementor/frontend/after_register_scripts', [$this, 'enqueue_scripts']);
    }

    /**
     * Admin notice - Missing main plugin
     */
    public function admin_notice_missing_main_plugin() {
        if (isset($_GET['activate'])) unset($_GET['activate']);

        $message = sprintf(
            esc_html__('"%1$s" requiere "%2$s" para funcionar. Por favor instala y activa Elementor.', 'horizontal-carousel'),
            '<strong>' . esc_html__('Horizontal Carousel', 'horizontal-carousel') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'horizontal-carousel') . '</strong>'
        );

        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    /**
     * Admin notice - Minimum Elementor version
     */
    public function admin_notice_minimum_elementor_version() {
        if (isset($_GET['activate'])) unset($_GET['activate']);

        $message = sprintf(
            esc_html__('"%1$s" requiere la versión "%2$s" o superior de Elementor.', 'horizontal-carousel'),
            '<strong>' . esc_html__('Horizontal Carousel', 'horizontal-carousel') . '</strong>',
            self::MINIMUM_ELEMENTOR_VERSION
        );

        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    /**
     * Admin notice - Minimum PHP version
     */
    public function admin_notice_minimum_php_version() {
        if (isset($_GET['activate'])) unset($_GET['activate']);

        $message = sprintf(
            esc_html__('"%1$s" requiere la versión "%2$s" o superior de PHP.', 'horizontal-carousel'),
            '<strong>' . esc_html__('Horizontal Carousel', 'horizontal-carousel') . '</strong>',
            self::MINIMUM_PHP_VERSION
        );

        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    /**
     * Register Widgets
     */
    public function register_widgets($widgets_manager) {
        require_once(__DIR__ . '/widgets/horizontal-carousel-widget.php');
        $widgets_manager->register(new \Horizontal_Carousel_Widget());
    }

    /**
     * Enqueue Styles
     */
    public function enqueue_styles() {
        wp_enqueue_style(
            'horizontal-carousel',
            plugins_url('assets/css/carousel.css', __FILE__),
            [],
            self::VERSION
        );

        // Enqueue Google Fonts
        wp_enqueue_style(
            'horizontal-carousel-fonts',
            'https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap',
            [],
            null
        );
    }

    /**
     * Enqueue Scripts
     */
    public function enqueue_scripts() {
        wp_register_script(
            'horizontal-carousel',
            plugins_url('assets/js/carousel.js', __FILE__),
            ['jquery'],
            self::VERSION,
            true
        );
    }
}

Horizontal_Carousel::instance();
