# Horizontal Carousel - Plugin de WordPress

Plugin de carrusel horizontal con scroll para Elementor que permite seleccionar categorías de posts.

## 🎯 Características

- ✅ Carrusel horizontal controlado por scroll
- ✅ Widget de Elementor con editor visual
- ✅ Selección de categoría de posts
- ✅ Diseño responsive y premium
- ✅ **Fix de scroll para contextos embebidos** (WordPress/Elementor)
- ✅ Navegación con flechas
- ✅ Carga dinámica de posts con imágenes destacadas

## 📦 Instalación

### Método 1: Manual

1. Descarga o copia la carpeta `horizontal-carousel`
2. Sube la carpeta a `/wp-content/plugins/` en tu instalación de WordPress
3. Ve a **Plugins** en el panel de WordPress
4. Activa el plugin **"Horizontal Carousel"**

### Método 2: Desde el repositorio

```bash
cd /wp-content/plugins/
# Copia la carpeta completa aquí
```

## ⚙️ Requisitos

- WordPress 5.0 o superior
- Elementor 3.0.0 o superior
- PHP 7.4 o superior
- Posts con imágenes destacadas (recomendado)

## 🚀 Uso

### 1. Agregar el widget a una página

1. Edita una página con **Elementor**
2. Busca el widget **"Horizontal Carousel"** en el panel de widgets
3. Arrastra el widget a tu página

### 2. Configurar el widget

#### Pestaña Contenido:

- **Categoría**: Selecciona la categoría de posts a mostrar (o "Todas las categorías")
- **Número de Posts**: Cuántos posts mostrar (1-50)
- **Ordenar Por**: Fecha, Título, Aleatorio, Orden del Menú
- **Orden**: Ascendente o Descendente

#### Pestaña Configuración:

- **Altura de Sección (vh)**: Controla la "velocidad" del scroll (200-800vh)
  - Valor más alto = scroll más lento
  - Recomendado: 400vh

#### Pestaña Estilo:

- **Color del Título**: Color del texto del título
- **Color del Botón**: Color del botón "Consultar"

### 3. Publicar

Haz clic en **"Publicar"** o **"Actualizar"** y visualiza tu página.

## 🛠️ Solución del Problema de Scroll

Este plugin **soluciona el problema** donde el carrusel mostraba los slides 4-5 primero en lugar del slide 1 cuando se integraba en WordPress/Elementor.

### ¿Qué se arregló?

- ✅ Cálculo de scroll usando posición relativa al viewport (`getBoundingClientRect()`)
- ✅ Eliminación de dependencia de `offsetTop` (que fallaba en contextos embebidos)
- ✅ El carrusel ahora **siempre empieza desde el slide 1**
- ✅ Funciona correctamente en bloques HTML de Elementor

## 📝 Personalización

### Cambiar estilos

Edita `/assets/css/carousel.css` para personalizar:
- Colores
- Tipografía
- Tamaños
- Animaciones

### Cambiar comportamiento

Edita `/assets/js/carousel.js` para modificar:
- Velocidad de scroll
- Animaciones
- Navegación

## 🔍 Troubleshooting

### El carrusel no se mueve

**Solución**: Asegúrate de que:
1. La sección tiene suficiente altura (mínimo 300vh)
2. Hay espacio suficiente para hacer scroll en la página
3. JavaScript está habilitado en el navegador

### No se muestran posts

**Solución**: Verifica que:
1. La categoría seleccionada tiene posts publicados
2. Los posts están en estado "Publicado"
3. Aumenta el número de posts en la configuración

### Las imágenes no se muestran

**Solución**:
1. Asegúrate de que los posts tengan **imagen destacada**
2. El plugin usa imagen de fallback si no hay imagen destacada
3. Verifica permisos de medios en WordPress

### El scroll sigue empezando mal

**Solución**:
1. Limpia el caché de WordPress/Elementor
2. Limpia el caché del navegador
3. Verifica que la versión del plugin esté actualizada

## 📄 Estructura de Archivos

```
horizontal-carousel/
├── horizontal-carousel.php          # Archivo principal del plugin
├── widgets/
│   └── horizontal-carousel-widget.php  # Widget de Elementor
├── assets/
│   ├── css/
│   │   └── carousel.css             # Estilos del carrusel
│   └── js/
│       └── carousel.js              # JavaScript con fix de scroll
└── README.md                        # Este archivo
```

## 🎨 Recomendaciones

1. **Imágenes**: Usa imágenes de alta calidad (mínimo 1920x1080px)
2. **Títulos**: Mantén los títulos cortos para mejor visualización
3. **Cantidad**: 5-10 slides es ideal para una buena experiencia
4. **Altura**: Empieza con 400vh y ajusta según necesites

## 💡 Próximas Mejoras

- [ ] Soporte para Custom Post Types
- [ ] Más opciones de estilo en Elementor
- [ ] Animaciones configurables
- [ ] Soporte para ACF (Advanced Custom Fields)

## 📧 Soporte

Si tienes problemas o preguntas, contacta al desarrollador.

## 📜 Licencia

GPL v2 o posterior

---

**Versión**: 1.0.0  
**Última actualización**: Febrero 2026
